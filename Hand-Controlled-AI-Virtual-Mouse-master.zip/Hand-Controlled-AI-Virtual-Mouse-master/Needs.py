# pip install opencv-python
import cv2
# pip install mediapipe
import mediapipe as mp
# pip install pyautogui
import pyautogui